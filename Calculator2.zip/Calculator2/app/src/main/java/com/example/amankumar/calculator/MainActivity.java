package com.example.amankumar.calculator;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button bt1,bt2,bt3,bt4,bt5,bt6;
    EditText et1,et2;
    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bt1 = (Button) findViewById(R.id.button1);
        bt2 = (Button) findViewById(R.id.button2);
        bt3 = (Button) findViewById(R.id.button3);
        bt4 = (Button) findViewById(R.id.button4);
        bt5 = (Button) findViewById(R.id.button5);
        bt6 = (Button) findViewById(R.id.button6);
        et1 = (EditText) findViewById(R.id.editTextNumberDecimal);
        et2 = (EditText) findViewById(R.id.editTextNumberDecimal2);
        tv = (TextView) findViewById(R.id.textView);

        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double ans = Double.parseDouble(et1.getText().toString()) + Double.parseDouble(et2.getText().toString());
                tv.setText("Addition is : "+ans);
            }
        });
        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double ans = Double.parseDouble(et1.getText().toString()) - Double.parseDouble(et2.getText().toString());
                tv.setText("Subtraction is : "+ans);
            }
        });
        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double ans = Double.parseDouble(et1.getText().toString()) / Double.parseDouble(et2.getText().toString());
                tv.setText("Division is : "+ans);
            }
        });
        bt5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double ans = Double.parseDouble(et1.getText().toString()) * Double.parseDouble(et2.getText().toString());
                tv.setText("Multiplication is : "+ans);
            }
        });
        bt4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double ans = Double.parseDouble(et1.getText().toString()) % Double.parseDouble(et2.getText().toString());
                tv.setText("Modulus is : "+ans);
            }
        });
        bt6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s = et1.getText().toString();
                double et1 = Double.parseDouble(s);
                String s1 = et2.getText().toString();
                double et2 = Double.parseDouble(s1);
                double ans = 1;
                for(double i=0;i<et2;i++){
                    ans = ans * et1;
                }
                tv.setText("Power is : "+ ans);
            }
        });
    }
}